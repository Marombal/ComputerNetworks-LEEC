#include "transmiter.h"

/*
*Function: Opens the channel to communicate as transmiter
*Return: returns 1 on sucess, -1 on error
*/
int llopen_transmiter(linkLayer connectionParameters){
    return -1;
}
/*
*Function: Closes the communication as transmiter
*Return: returns 1 on sucess, -1 on error
*/
int llclose_transmiter(){
    return -1;
}
// NAO SEI QUAIS SERAO OS PARAMETROS NECESSARIOS