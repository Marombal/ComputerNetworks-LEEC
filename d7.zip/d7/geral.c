#include "geral.h"

int setupSerialTerminal(linkLayer connectionParameters){
    return -1;
}
int stuffing(){
    return -1;
}
int destuffing(){
    return -1;
}

//int closeSerialTerminal(int fd);

