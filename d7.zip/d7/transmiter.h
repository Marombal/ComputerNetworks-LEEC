#ifndef TRANSMITER_H
#define TRANSMITER_H

#include "geral.h"

/*
*Function: Opens the channel to communicate as transmiter
*Return: returns 1 on sucess, -1 on error
*/
int llopen_transmiter(linkLayer connectionParameters);
/*
*Function: Closes the communication as transmitter
*Return: returns 1 on sucess, -1 on error
*/
int llclose_transmiter(); // NAO SEI QUAIS SERAO OS PARAMETROS NECESSARIOS

#endif