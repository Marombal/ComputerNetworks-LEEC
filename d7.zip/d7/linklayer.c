/* INCLUDES .h*/
#include "linklayer.h"
#include "receiver.h"
#include "transmiter.h"
#include "geral.h"
#include "defines.h"

// Opens a conection using the "port" parameters defined in struct linkLayer, returns "-1" on error and "1" on sucess
int llopen(linkLayer connectionParameters)
{
    if(connectionParameters.role == RECEIVER){
        //... abre como receiver
        return llopen_receiver(connectionParameters); 
    }
    if(connectionParameters.role == TRANSMITTER){
        //... abre como transmiter
        return llopen_transmiter(connectionParameters); 
    }

    return -1;
}
// Sends data in buf with size bufSize
int llwrite(char* buf, int bufSize){
    return -1;
}
// Receive data in packet
int llread(char* packet){
    return -1;
}
// Closes previously opened connection; if showStatistics==TRUE, link layer should print statistics in the console on close
int llclose(int showStatistics){
    return -1;
}