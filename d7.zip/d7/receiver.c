#include "receiver.h"

/*
*Function: Opens the channel to communicate as receiver
*Return: returns 1 on sucess, -1 on error
*/
int llopen_receiver(linkLayer connectionParameters){
    return -1;
}
/*
*Function: Closes the communication as receiver
*Return: returns 1 on sucess, -1 on error
*/
int llclose_receiver(){
    return -1;
}
// NAO SEI QUAIS SERAO OS PARAMETROS NECESSARIOS