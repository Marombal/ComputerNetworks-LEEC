#ifndef GERAL_H
#define GERAL_H

#include "linklayer.h"
#include "defines.h"

static struct termios oldtio, newtio;

int setupSerialTerminal(linkLayer connectionParameters);
int stuffing();
int destuffing();
//int closeSerialTerminal(int fd);

#endif